package com.example.task0_ui_shared_preference_intent

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sharedPreference = getSharedPreferences(CommonKeys.KEY_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreference.edit()

        // To check login state
        val switch = true
        editor.putBoolean(CommonKeys.KEY_LOGIN_STATE, switch)
        val getName = sharedPreference.getBoolean(CommonKeys.KEY_LOGIN_STATE, true)


        // To hide status bar
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        //Splash screen
        Handler(Looper.getMainLooper()).postDelayed({

            if (getName) {
                val intent = Intent(this, signupActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                val intent = Intent(this, mainScreen::class.java)
                startActivity(intent)
                finish()

            }


        }, ProjectConstants.TIMER_FOR_SPLASH.toLong())


    }
}