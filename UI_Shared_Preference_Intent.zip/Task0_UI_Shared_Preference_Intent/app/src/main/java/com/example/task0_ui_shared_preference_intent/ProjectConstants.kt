package com.example.task0_ui_shared_preference_intent

object ProjectConstants {
    const val TIMER_FOR_SPLASH = 3000
}