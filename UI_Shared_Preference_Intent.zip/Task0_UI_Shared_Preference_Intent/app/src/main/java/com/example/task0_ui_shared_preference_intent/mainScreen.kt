package com.example.task0_ui_shared_preference_intent

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class mainScreen : AppCompatActivity() {

    lateinit var editButton: Button
    lateinit var name1: EditText
    lateinit var email1: EditText
    lateinit var password1: EditText
    lateinit var username: TextView
    lateinit var toolbar: Toolbar
    lateinit var showHide: ImageView
    lateinit var nameMessage: TextView
    lateinit var emailMessage: TextView
    lateinit var passMessage: TextView

    //this switch is for button changing
    var switch: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)
        callingViews()
        clickListeners()
        val sharedPreference = getSharedPreferences(CommonKeys.KEY_PREF_NAME, Context.MODE_PRIVATE)



        setSupportActionBar(toolbar)
        (this as AppCompatActivity).supportActionBar?.title = getString(R.string.profile_page_title)




        // getting values throw shared preferences
        val getName = sharedPreference.getString(CommonKeys.KEY_NAME, "").toString()
        val getEmail = sharedPreference.getString(CommonKeys.KEY_EMAIL, "").toString()
        val getPassword = sharedPreference.getString(CommonKeys.KEY_PASSWORD, "").toString()


        // setting values in edittext fields
        name1.setText(getName)
        email1.setText(getEmail)
        password1.setText(getPassword)
        username.text = getName

        // this will prevent the keyboard to open
        name1.isFocusableInTouchMode = false
        email1.isFocusableInTouchMode = false
        password1.isFocusableInTouchMode = false

        // this will prevent copy and paste
        name1.isLongClickable = false
        email1.isLongClickable = false
        password1.isLongClickable = false


    }


    //item menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.logout, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here.
        val id = item.getItemId()

        if (id == R.id.logout) {
            //dialog box
            val dialog = AlertDialog.Builder(this)

            dialog.setTitle(getString(R.string.logout))
                .setMessage(getString(R.string.sure_to_logout))
                .setPositiveButton(getString(R.string.yes)) { dialog, whichButton ->
                    //deleting name,email,password from shared preferences
                    val sharedPreference =
                        getSharedPreferences(CommonKeys.KEY_PREF_NAME, Context.MODE_PRIVATE)
                    val editor = sharedPreference.edit()
                    editor.remove(CommonKeys.KEY_PREF_NAME)
                    editor.remove(CommonKeys.KEY_EMAIL)
                    editor.remove(CommonKeys.KEY_PASSWORD)
                    editor.putBoolean(CommonKeys.KEY_LOGIN_STATE, true)
                    editor.apply()


                    val intent = Intent(this, signupActivity::class.java)
                    startActivity(intent)
                    finish()
                }.setNegativeButton(getString(R.string.no)) { dialog, whichButton ->
                    dialog.cancel()
                }

            dialog.show()

            return true
        }

        return super.onOptionsItemSelected(item)

    }

    private fun clickListeners() {

        nameMessage.visibility = View.GONE
        emailMessage.visibility = View.GONE
        passMessage.visibility = View.GONE
        showHide.setOnClickListener(View.OnClickListener {
            if (password1.transformationMethod.equals(HideReturnsTransformationMethod.getInstance())) {
                password1.transformationMethod = PasswordTransformationMethod.getInstance()
            } else {
                password1.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }

        })

        editButton.setOnClickListener(View.OnClickListener {
            val sharedPreference = getSharedPreferences(CommonKeys.KEY_PREF_NAME, Context.MODE_PRIVATE)
            val editor = sharedPreference.edit()
            val namedata = name1.text.toString()
            val emaildata = email1.text.toString()
            val passworddata = password1.text.toString()

            if (switch == true) {
                editButton.text = getString(R.string.change_button_to_done_changes)
                name1.isFocusableInTouchMode = true
                email1.isFocusableInTouchMode = true
                password1.isFocusableInTouchMode = true
                switch = false


                if (name1.text.isEmpty() || email1.text.isEmpty() || password1.text.isEmpty()) {
                    if (name1.text.isEmpty()) {
                        nameMessage.visibility = View.VISIBLE

                    } else {
                        nameMessage.visibility = View.GONE
                    }

                    if (email1.text.isEmpty()) {
                        emailMessage.visibility = View.VISIBLE
                    } else {
                        emailMessage.visibility = View.GONE
                    }

                    if (password1.text.isEmpty()) {
                        passMessage.visibility = View.VISIBLE
                    } else {
                        passMessage.visibility = View.GONE

                    }

                }


            } else {
                if (name1.text.isEmpty() || email1.text.isEmpty() || password1.text.isEmpty()) {
                    if (name1.text.isEmpty()) {
                        nameMessage.visibility = View.VISIBLE

                    } else {
                        nameMessage.visibility = View.GONE
                    }

                    if (email1.text.isEmpty()) {
                        emailMessage.visibility = View.VISIBLE
                    } else {
                        emailMessage.visibility = View.GONE
                    }

                    if (password1.text.isEmpty()) {
                        passMessage.visibility = View.VISIBLE
                    } else {
                        passMessage.visibility = View.GONE

                    }

                } else {
                    //disabling textfields again
                    editButton.text = getString(R.string.change_button_to_edit_details)
                    name1.isFocusableInTouchMode = false
                    email1.isFocusableInTouchMode = false
                    password1.isFocusableInTouchMode = false
                    name1.isLongClickable = false
                    email1.isLongClickable = false
                    password1.isLongClickable = false
                    switch = true
                    //overwriting new values in shared preferences
                    editor.putString(CommonKeys.KEY_NAME, namedata)
                    editor.putString(CommonKeys.KEY_EMAIL, emaildata)
                    editor.putString(CommonKeys.KEY_PASSWORD, passworddata)
                    editor.apply()
                    Toast.makeText(this, getString(R.string.updating), Toast.LENGTH_SHORT).show()
                    this.recreate();

                }


            }

        })


    }

    private fun callingViews() {
        nameMessage = findViewById(R.id.nameMessageMain)
        emailMessage = findViewById(R.id.emailMessageMain)
        passMessage = findViewById(R.id.passMessageMain)
        toolbar = findViewById(R.id.toolbar)
        editButton = findViewById(R.id.editButtonMain)
        name1 = findViewById(R.id.nameMain)
        email1 = findViewById(R.id.emailMain)
        password1 = findViewById(R.id.passwordMain)
        username = findViewById(R.id.userNameMain)
        showHide = findViewById(R.id.showHideMain)
    }


}