package com.example.task0_ui_shared_preference_intent

object CommonKeys {
    const val KEY_PREF_NAME = "_key_login_system"
    const val KEY_NAME = "_key_name"
    const val KEY_EMAIL = "_key_email"
    const val KEY_PASSWORD = "_key_password"
    const val KEY_LOGIN_STATE = "_key_login_state"


}