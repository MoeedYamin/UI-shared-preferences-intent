package com.example.task0_ui_shared_preference_intent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class signupActivity : AppCompatActivity() {

    lateinit var signup: Button
    lateinit var name: EditText
    lateinit var email: EditText
    lateinit var password: EditText
    lateinit var showHide: ImageView
    lateinit var nameMessage: TextView
    lateinit var emailMessage: TextView
    lateinit var passMessage: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        callingViews()
        clickListeners()


    }

    private fun clickListeners() {

        nameMessage.visibility = View.GONE
        emailMessage.visibility = View.GONE
        passMessage.visibility = View.GONE

        showHide.setOnClickListener(View.OnClickListener {
            if (password.transformationMethod.equals(HideReturnsTransformationMethod.getInstance())) {
                password.transformationMethod = PasswordTransformationMethod.getInstance()
            } else {
                password.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }

        })


        signup.setOnClickListener(View.OnClickListener {

            val nameData = name.text.toString()
            val emailData = email.text.toString()
            val passwordData = password.text.toString()


            // These ifs conditions are for when we press the button,
            // it shows the error message by checking it.
            if (name.text.isEmpty()) {
                nameMessage.visibility = View.VISIBLE

            } else {
                nameMessage.visibility = View.GONE
            }

            if (email.text.isEmpty()) {
                emailMessage.visibility = View.VISIBLE
            } else {
                emailMessage.visibility = View.GONE
            }

            if (password.text.isEmpty()) {
                passMessage.visibility = View.VISIBLE
            } else {
                passMessage.visibility = View.GONE

            }



            if (name.text.isNotEmpty() && email.text.isNotEmpty() && password.text.isNotEmpty()) {
                val sharedPreference = getSharedPreferences(CommonKeys.KEY_PREF_NAME, Context.MODE_PRIVATE)
                val editor = sharedPreference.edit()
                //saving in shared preferences if all fields are filled
                editor.putString(CommonKeys.KEY_NAME, nameData)
                editor.putString(CommonKeys.KEY_EMAIL, emailData)
                editor.putString(CommonKeys.KEY_PASSWORD, passwordData)
                editor.putBoolean(CommonKeys.KEY_LOGIN_STATE, false)
                editor.apply()

                Toast.makeText(this, getString(R.string.login), Toast.LENGTH_SHORT).show()
                val intent = Intent(this, mainScreen::class.java)
                startActivity(intent)
                finish()

            }

        })
    }

    private fun callingViews() {
        signup = findViewById(R.id.signup)
        name = findViewById(R.id.nameSignup)
        email = findViewById(R.id.emailSignup)
        password = findViewById(R.id.passwordSignup)
        showHide = findViewById(R.id.showHideSignup)
        nameMessage = findViewById(R.id.nameMessageSignup)
        emailMessage = findViewById(R.id.emailMessageSignup)
        passMessage = findViewById(R.id.passMessageSignup)
    }


}